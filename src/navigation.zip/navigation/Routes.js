import React from 'react';
import { Route,BrowserRouter as Router,Switch } from  'react-router-dom';
// import Home from '../pages/home/home';
import Header from '../components/header/header';
import iphone12 from '../pages/iphone12/iphone12';
import Signin from '../pages/Signin/Signin';
import Signup from '../pages/Signup/Signup';
// import Footer from '../components/footer/footer';
// import tv from '../pages/tv/tv'
// import music from '../pages/music/music';
// import Support from '../pages/support/support';


function Routes() {
    return(
            <Router>
                        <div>
                            
                            <Header/>
                        
                            
                        </div>
                            {/* <Switch>
                                    <Route exact path="/" component={Home}/>
                            </Switch> */}
                            
                            {/* <Switch>
                                    <Route exact path="/" component={tv}/>
                            </Switch> */}

                            {/* <Switch>
                                    <Route exact path="/" component={music}/>
                            </Switch> */}

                            {/* <Switch>
                                    <Route exact path="/" component={Support}/>
                            </Switch> */}

                            {/* <Switch>
                                    <Route exact path="/" component={iphone12}/>
                            </Switch> */}

                            {/* <Switch>
                                    <Route exact path="/" component={Signin}/>
                            </Switch> */}
                            <Switch>
                                    <Route exact path="/" component={Signup}/>
                            </Switch>
                    
                        <div>

                            {/* <Footer/> */}
                            
                        </div>
            
          </Router>

    );
}

export default Routes;

